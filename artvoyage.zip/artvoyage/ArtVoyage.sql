-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 18, 2024 at 08:39 AM
-- Server version: 5.7.39
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ArtVoyage`
--

-- --------------------------------------------------------

--
-- Table structure for table `Feedback`
--

CREATE TABLE `Feedback` (
  `Name` varchar(255) DEFAULT NULL,
  `Comment` varchar(255) DEFAULT NULL,
  `Rate` enum('1','2','3','4','5') DEFAULT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Feedback`
--

INSERT INTO `Feedback` (`Name`, `Comment`, `Rate`, `ID`) VALUES
('Sumaia', 'Good', '4', 1),
('Alia', 'Nice', '3', 2),
('Amna', 'WOW', '5', 3),
('Ali', 'Not bad', '3', 4),
('Amal', 'I like it', '4', 5),
('Zayed', 'Need improvement', '2', 6),
('Alia', 'good', '4', 7);

-- --------------------------------------------------------

--
-- Table structure for table `Items`
--

CREATE TABLE `Items` (
  `ID` int(8) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Type` enum('Photography','Painting','Sculpture') DEFAULT NULL,
  `Price` float NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Items`
--

INSERT INTO `Items` (`ID`, `Name`, `Type`, `Price`, `Image`, `User_ID`, `Description`) VALUES
(1, 'Peaceful River', 'Painting', 150, '../images/peaceful-river.jpg', 3, 'Serene painting portraying a winding river bordered by lush greenery under a clear blue sky, radiating tranquility and natural beauty.'),
(2, 'Contemplation', 'Sculpture', 80, '../images/family-contemplation .jpg', 3, 'A heartfelt sculpture portraying a family seated together in quiet contemplation, their postures conveying a sense of unity and introspection.'),
(3, 'Green Reflection', 'Photography', 100, '../images/green-reflection.jpg', 3, 'Mirror placed in grass, showing clear reflection of a man, prompting contemplation on nature and self.'),
(4, 'Cozy Kitchen', 'Painting', 175, '../images/cozy-kitchen.jpg', 3, 'A charming painting capturing the warmth of a messy kitchen, filled with scattered utensils, ingredients, and homely chaos, evoking feelings of comfort and familiarity.'),
(5, 'Verdant Dusk', 'Photography', 240, '../images/verdant-dusk.jpg', 5, 'A tranquil beauty of lush green mountains against a brooding, darkening sky, blending natures serenity with an impending sense of mystery.'),
(6, 'Pyramids and Palms', 'Photography', 300, '../images/pyramids-palms.jpg', 5, 'Showcases the timeless allure of ancient wonders juxtaposed against vibrant palm trees and tranquil waters, evoking a scene of serene majesty amidst the arid desert landscape'),
(7, 'Crimson Aroma', 'Photography', 210, '../images/crimson-aroma.jpg', 5, 'Captures the ethereal beauty of lush red fields, where fragrant smoke rises from the tranquil landscape, intertwining with the rich cultural heritage and natural splendor of Vietnams countryside.'),
(8, 'Chefchaouens Charm', 'Photography', 190, '../images/chefchaouens-charm.jpg', 5, 'Captures the enchanting allure of Moroccos famed Blue City, where a solitary door amidst azure hues invites wanderers into a world of timeless beauty and serenity.'),
(9, 'Dunes of Destiny', 'Photography', 285, '../images/ journey-across-sands.jpg', 7, 'Amidst the golden dunes, a solitary traveler embarks on a timeless journey atop a camel, weaving through the vast expanse of the desert, each step a testament to the enduring spirit of exploration and adventure.'),
(10, 'Clay Vessels', 'Photography', 120, '../images/clay-vessels.jpg', 7, 'Captures the essence of tradition and craftsmanship in a bustling marketplace. Amongst the vibrant colors and sounds of the souq, each piece telling a story of skill and heritage.'),
(11, 'Golden Fur', 'Painting', 120, '../images/golden-fur.jpg', 8, 'Vibrant presence of an orange cat, its fur radiating warmth and charm against a simple backdrop'),
(12, 'Cotton Candy Sky', 'Painting', 80, '../images/cotton-candy-sky.jpg', 8, 'Fluffy clouds drifting against a pastel backdrop, evoking a serene atmosphere of wonder.'),
(13, 'Lapine Ensemble', 'Sculpture', 90, '../images/lapine-ensemble.jpg', 11, 'Features a lively gathering of rabbits, each displaying playful antics and endearing charm.'),
(14, 'Clay in Wonder', 'Sculpture', 130, '../images/clay-in-wonder.jpg', 11, 'A moment of contemplation, a figure crafted from clay lost in the depths of wonder.');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `ID` int(8) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Role` enum('Admin','User') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`ID`, `FirstName`, `LastName`, `Email`, `Password`, `Role`) VALUES
(1, 'Alia', 'Ali', 'alia@gmail.com', 'Alia#123', 'User'),
(2, 'Hamda', 'Rashed', 'hamda@gmail.com', 'Hamda#372', 'User'),
(3, 'Sumaia', 'Ali', 'sumaia@outlook.com', 'Sumaia#123', 'Admin'),
(4, 'Amal', 'Khaled', 'amal@gmail.com', 'Amal#123', 'User'),
(5, 'Mariam', 'Zayed', 'mariam@hotmail.com', 'Mariam$123', 'Admin'),
(6, 'Layla', 'Salem', 'layla@gmail.com', 'Layla%123', 'User'),
(7, 'Saif', 'Abdulla', 'saif@gmail.com', 'Saif&123', 'Admin'),
(8, 'Meera', 'Ahmed', 'meera@gmail.com', 'Meera&123', 'Admin'),
(9, 'Noor', 'Rashed', 'noor@hotmail.com', 'Noor&123', 'User'),
(10, 'Khalid', 'Mohammed', 'khalid@outlook.com', 'Khalid@123', 'User'),
(11, 'Mansoor', 'Ahmed', 'mansoor@gmail.com', 'Mansoor$123', 'Admin'),
(12, 'Reem', 'Ali', 'reem@outlook.com', 'Reem#123', 'User'),
(13, 'Fatima', 'Ali', 'fatima@outlook.com', 'Fatima#123', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Feedback`
--
ALTER TABLE `Feedback`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Items`
--
ALTER TABLE `Items`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Feedback`
--
ALTER TABLE `Feedback`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Items`
--
ALTER TABLE `Items`
  MODIFY `ID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `ID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Items`
--
ALTER TABLE `Items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `User` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
