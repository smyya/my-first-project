<?php

require_once 'connection.php';
session_start();

$request = $_POST["request"]; 
$result = "";
switch ($request) {
    case "get_theme":
        $result=get_theme();
        break;
    case "edit_theme":
        $result=edit_theme($_POST["theme"]);
    case "get_full_name":
        $result = get_full_name($connection);
        break;
    case "get_items":
        $result = get_items($connection, $_POST["item_name"], $_POST["item_type"], $_POST["sort_by"],$_POST["sort_type"]);
        break;
    case "add_item":
        $result = add_item($connection, $_SESSION["user_id"], $_POST["item_name"], $_POST["image"], $_POST["price"], $_POST["type"], $_POST["description"]);
        break;
    case "delete_item":
        $result = delete_item($connection, $_POST["item_id"]);
        break;
    case "save_feedback":
        $result = save_feedback($connection, $_POST["name"], $_POST["comment"], $_POST["rate"]);
        break;
    case "get_user_feedback":
        $result = get_user_feedback($connection);
        break;
    case "get_new_items":
        $result = get_new_items($connection);
        break;
    case "logout":
        $result = logout();
        break;
}

echo $result;

// function to get the theme.
function get_theme(){
    $result=array("theme"=>"light");
    if(isset($_COOKIE["theme"])){
        $result["theme"]=$_COOKIE["theme"];
    }
    return json_encode($result);
}

// function to edit the theme.
function edit_theme($theme){
    // set theme cookie for 7 days.
    setcookie('theme', $theme, time() + 60*60*24*7, '/');
    return json_encode(array("success"=>true));
}

// function to display the user's full name.
function get_full_name($connection) {
    // get the user ID from the session.
    $user_id = $_SESSION["user_id"];
    // retrieve the user's first name and last name based on their ID.
    $query = "SELECT FirstName,LastName FROM User WHERE ID='$user_id'";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_array($result);
    // add the first name and last name to show the full name.
    $full_name = $row["FirstName"] . " " . $row["LastName"];
    return json_encode(array("full_name" => $full_name));
}

// function to get the items.
function get_items($connection, $item_name, $item_type, $sort_by,$sort_type) {
    // get the user ID from the session.
    $user_id = $_SESSION["user_id"];
    
    // retrieve the user's role.
    $query = "SELECT Role FROM User WHERE ID='$user_id'";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    $user_role = $row['Role'];

    // check if the user's role is user or admin.
    if ($user_role == 'User') {
        // users can see all items.
        $item_type_where = "TRUE";
    } elseif ($user_role == 'Admin') {
        // admins can only see items associated with their ID.
        $item_type_where = "User.ID='$user_id'";
    }

    // will be used for the dropdown menu.
    if (!empty($item_type)) {
        $item_type_where .= " AND Type='$item_type'";
    }
    
    // retrieve items id, name, price, image, type, description, and the users first name and last name.
    $query = "SELECT Items.ID AS item_id, Items.Name, Items.User_ID, Items.Price, Items.Image, Items.Type, Items.Description, User.FirstName, User.LastName 
    FROM Items 
    INNER JOIN User ON Items.User_ID=User.ID 
    WHERE $item_type_where AND Items.Name LIKE '%$item_name%' 
    ORDER BY $sort_by $sort_type";

    $result = mysqli_query($connection, $query); 

    if (!$result)
        die("Database access failed: " . mysqli_error($connection));

    $data_set = array();
    while ($row = mysqli_fetch_array($result)) { 
        $item_id = $row["item_id"];
        $item_name = $row["Name"];
        $item_artist = $row["FirstName"]. " " .$row["LastName"];
        $price = $row["Price"];
        $image = $row["Image"];
        $item_type = $row["Type"]; 
        $description = $row["Description"]; 
        $data_row = array("item_id" => $item_id , "item_name" => $item_name, "item_artist" => $item_artist, "price" => $price, "image" => $image, "item_type" => $item_type, "description" => $description);
        $data_set[] = $data_row;
    }
    return json_encode($data_set);
}

// function to add items.
function add_item($connection, $user_id, $item_name, $image, $price, $type, $description) {
    // insert the items data into the table Items in the database.
    $query = "INSERT INTO Items (User_ID, Name,Image,Price,Type,Description) VALUES ('$user_id', '$item_name','$image','$price', '$type', '$description')";
    $result = mysqli_query($connection, $query);
    if (!$result) {
        return json_encode(array("success" => false));
    }
    return json_encode(array("success" => true));
}

// function to delete items.
function delete_item($connection, $item_id) {
    // delete the item from the database.
    $query = "DELETE FROM Items WHERE Items.ID='$item_id'";
    $result = mysqli_query($connection, $query);
    if (!$result) {
        return json_encode(array("success" => false));
    }
    return json_encode(array("success" => true));
}

// function to add feedbacks.
function save_feedback($connection, $name, $comment, $rate) {
    // insert the feedbacks data into the Feedback table in the database.
    $query = "INSERT INTO Feedback (Name, Comment, Rate) VALUES ('$name', '$comment', '$rate')";
    $result = mysqli_query($connection, $query);
    if (!$result) {
        return json_encode(array("success" => false));
    }
    return json_encode(array("success" => true));
}

// function to get the feedbacks.
function get_user_feedback($connection) {
    // retrieve the 5 most recent feedbacks.
    $query = "SELECT * FROM Feedback ORDER BY ID DESC LIMIT 5";
    $result = mysqli_query($connection, $query);
    // check if there are no feedbacks or there is an error.
    if (!$result || mysqli_num_rows($result) === 0) {
        // return an empty array if there is no feedbacks.
        return json_encode(array()); 
    }
    // array to store retrieved feedbacks.
    $feedback_data = array();
    // loop and add feedbacks into the array.
    while ($row = mysqli_fetch_assoc($result)) {
        $feedback_data[] = $row; 
    }
    return json_encode($feedback_data);
}

// function to get the new items.
function get_new_items($connection) {
    // retrieve the 6 most recent items.
    $query = "SELECT * FROM Items ORDER BY ID DESC LIMIT 6";
    $result = mysqli_query($connection, $query);
    // check if there are no items or there is an error.
    if (!$result || mysqli_num_rows($result) === 0) {
        // return an empty array if there is no items.
        return json_encode(array());
    }
    // array to store retrieved items.
    $new_items_data = array();
    // loop and add items into the array.
    while ($row = mysqli_fetch_assoc($result)) {
        $new_items_data[] = $row; 
    }
    return json_encode($new_items_data);
}

// function to logout.
function logout() {
        $_SESSION = array();
    
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        return json_encode(array("success" => true));
    }
    