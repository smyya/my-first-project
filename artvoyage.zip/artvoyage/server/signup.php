<?php

require_once 'connection.php';

// check if firstname, lastname, role, email and password is set.
if (isset($_POST["firstname"]) && isset($_POST["lastname"]) && isset($_POST["role"]) && isset($_POST["email"]) && isset($_POST["password"])) {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $role = $_POST["role"];

    // check if the email already exists in the database
    $emailCheckQuery = "SELECT * FROM User WHERE Email='$email'";
    $emailCheckResult = mysqli_query($connection, $emailCheckQuery);
    
    // if the email already exists, send an alert
    if(mysqli_num_rows($emailCheckResult) > 0) {
        echo json_encode(array("success" => false, "message" => "Email already exists."));
        exit;
    }

    // insert the user data into the table User in the database.
    $query = "INSERT INTO User (FirstName, LastName, Role, Email, Password) VALUES ('$firstname', '$lastname', '$role', '$email', '$password')";
    $result = mysqli_query($connection, $query);
    if ($result) {
        echo json_encode(array("success" => true));
    } else {
        echo json_encode(array("success" => false));
    }
} else {
    echo json_encode(array("success" => false));
}
?>
