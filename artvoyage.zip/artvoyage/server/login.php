<?php

require_once 'connection.php';

// check if email and password are set.
if (isset($_POST["email"]) && isset($_POST["password"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $query = "SELECT * FROM User WHERE Email='$email' AND Password='$password'";
    $result = mysqli_query($connection, $query);
    $num_rows = mysqli_num_rows($result);
    // if one row is returned, then login is successful
    if ($num_rows == 1) {
        $row = mysqli_fetch_assoc($result);
        session_start();
        // store the users ID in a session.
        $_SESSION["user_id"] = $row["ID"];
        // return success response with user role (admin or user).
        echo json_encode(array("success" => true, "role" => $row["Role"]));
    } else {
        echo json_encode(array("success" => false));
    }
} else {
    echo json_encode(array("success" => false));
}
?>
