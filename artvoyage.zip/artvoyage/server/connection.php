<?php 
//data that is needed to connect to MySQL 
  $db_hostname = 'localhost';
  $db_database = 'ArtVoyage';
  $db_username = 'root';
  $db_password = 'root';
  
  $connection = mysqli_connect($db_hostname, $db_username, $db_password, $db_database);
  
      if (!$connection) // exit from the page, and show the error message
        die("Unable to connect to MySQL: " . mysqli_connect_errno());

