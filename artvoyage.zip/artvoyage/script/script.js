// sort item by name icon.
var a_z_sort_icon="<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-sort-alpha-down' viewBox='0 0 16 16'><path fill-rule='evenodd' d='M10.082 5.629 9.664 7H8.598l1.789-5.332h1.234L13.402 7h-1.12l-.419-1.371h-1.781zm1.57-.785L11 2.687h-.047l-.652 2.157h1.351z'/><path d='M12.96 14H9.028v-.691l2.579-3.72v-.054H9.098v-.867h3.785v.691l-2.567 3.72v.054h2.645V14zM4.5 2.5a.5.5 0 0 0-1 0v9.793l-1.146-1.147a.5.5 0 0 0-.708.708l2 1.999.007.007a.497.497 0 0 0 .7-.006l2-2a.5.5 0 0 0-.707-.708L4.5 12.293V2.5z'/></svg>";
var z_a_sort_icon='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sort-alpha-down-alt" viewBox="0 0 16 16"><path d="M12.96 7H9.028v-.691l2.579-3.72v-.054H9.098v-.867h3.785v.691l-2.567 3.72v.054h2.645V7z"/><path fill-rule="evenodd" d="M10.082 12.629 9.664 14H8.598l1.789-5.332h1.234L13.402 14h-1.12l-.419-1.371h-1.781zm1.57-.785L11 9.688h-.047l-.652 2.156h1.351z"/><path d="M4.5 2.5a.5.5 0 0 0-1 0v9.793l-1.146-1.147a.5.5 0 0 0-.708.708l2 1.999.007.007a.497.497 0 0 0 .7-.006l2-2a.5.5 0 0 0-.707-.708L4.5 12.293V2.5z"/></svg>';
// sort item by price icon.
var sort_up='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sort-up" viewBox="0 0 16 16"><path d="M3.5 12.5a.5.5 0 0 1-1 0V3.707L1.354 4.854a.5.5 0 1 1-.708-.708l2-1.999.007-.007a.498.498 0 0 1 .7.006l2 2a.5.5 0 1 1-.707.708L3.5 3.707V12.5zm3.5-9a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zM7.5 6a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5zm0 3a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3zm0 3a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1h-1z"/></svg>';
var sort_down='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sort-down" viewBox="0 0 16 16"><path d="M3.5 2.5a.5.5 0 0 0-1 0v8.793l-1.146-1.147a.5.5 0 0 0-.708.708l2 1.999.007.007a.497.497 0 0 0 .7-.006l2-2a.5.5 0 0 0-.707-.708L3.5 11.293V2.5zm3.5 1a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zM7.5 6a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5zm0 3a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3zm0 3a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1h-1z"/></svg>';
var sort_type_g="ASC";
var sort_by_g="Items.Name";

// theme will be set as light initially.
var current_theme="light";

// function to retrieve the current theme.
function get_theme(){
    $.ajax({method:"POST",
        url:"../server/controller.php",
        dataType:"json",
        data:{request:"get_theme"},
        success:function(data){
            current_theme=data["theme"];
            if(current_theme=="light"){
                light_theme();
            }
            else{
                dark_theme();
            }
        }     
    });  
}

// function to update the theme.
function edit_theme(){
       $.ajax({method:"POST",
        url:"../server/controller.php",
        dataType:"json",
        data:{request:"edit_theme","theme":current_theme},
        success:function(data){
        }     
    });  
}

// function to apply when using the dark theme.
function dark_theme(){
    $("body").css({"background-color":"#1e3756af","color":"white"});
    $("h1").css("color", "white");
    $(".modal-content").css("background-color", "#8ca3bb");
    $("#theme_button").html("&#127774;");
}

// function to apply when using the light theme.
function light_theme(){
    $("body").css({"background-color":"#EBEDF2","color":"black"});
    $("h1").css("color", "black");
    $(".modal-content").css("background-color", "#bcc7d3");
    $("#theme_button").html("&#127769;");
}

// function to switch between light and dark themes.
function switch_theme(){
    if(current_theme=="light"){
       dark_theme();
       current_theme="dark";
    }
    else{
        light_theme();
        current_theme="light";
    }
    // update the theme
    edit_theme();
}


// set icons for soting
function assign_sort_icons(){
    $("#item-sort-icon").html(z_a_sort_icon);
    $("#price-sort-icon").html(sort_down);
}

// login function
function login() {
    var email = $("#email").val();
    var password = $("#password").val();
    $.ajax({method: "POST",
        url: "server/login.php",
        dataType: "json",
        data: {email: email, password: password},
        success: function (data) {
            if (data["success"]) {
                // check if user is an admin or user
                var role = data["role"];
                if (role === "Admin") {
                    // if its an admin redirect to adminitems.html
                    location.href = 'html/adminitems.html';
                } else if (role === "User") {
                    // if its a user redirect to items.html
                    location.href = 'html/homepage.html';
                }
            } else {
                $("#error_message").show();
            }
        }
    });
}


// show name function
function get_full_name() {
    $.ajax({method: "POST",
        url: "../server/controller.php",
        dataType: "json",
        data: {request: "get_full_name"},
        success: function (data) {
            var full_name=data["full_name"];
            $("#full_name").text(full_name);
        }
    });
}

// logout function
function logout() {
    $.ajax({method: "POST",
        url: "../server/controller.php",
        dataType: "json",
        data: {request: "logout"},
        success: function (data) {
            if(data["success"]){
                location.href = '../index.html';
            }
        }
    });
}

// function to signup
function signup() {
    var firstname = $("#firstname").val();
    var lastname = $("#lastname").val();
    var role = $("input[name='role']:checked").val();
    var email = $("#email").val();
    var password = $("#password").val();

    // check if any of the fields are empty.
    if (firstname.trim() === "" || lastname.trim() === "" || email.trim() === "" || password.trim() === "" || !role) {
        alert("Please fill in all the fields.");
        return; 
    }

    // the regular expression for email validation.
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    // check if email is valid
    if (!emailRegex.test(email)) {
        // display an alert if email is invalid.
        alert("Please enter a valid email address."); 
        return; 
    }

    // check password strength.
    var passwordErrors = isPasswordStrong(password);
    // if password doesn't meet the requirements.
    if (passwordErrors !== true) {
        // display the unmet password requirements.
        alert("Password requirements:\n" + passwordErrors.join("\n"));
        return; 
    }

    // if all fields are filled and password is strong, continue with signup.
    $.ajax({
        method: "POST",
        url: "../server/signup.php",
        dataType: "json",
        data: { firstname: firstname, lastname: lastname, role: role, email: email, password: password },
        success: function (data) {
            if (data["success"]) {
                // user will go to the login page if signup is successful.
                location.href = '../index.html'
            } else {
                // send an alert if email already exists.
                if(data["message"] && data["message"] === "Email already exists.") {
                    alert(data["message"]);
                } else {
                    // a error message will shown if signup is failed.
                    alert("Signup failed. Please try again.");
                }
            }
        }
    });
}

// the function to check password strength.
function isPasswordStrong(password) {
    var errors = [];
    // check if password length is at least 8 characters.
    if (password.length < 8) {
        errors.push("Password must be at least 8 characters long.");
    }
    // check if password contains at least one lowercase letter.
    if (!/[a-z]/.test(password)) {
        errors.push("Password must contain at least one lowercase letter.");
    }
    // check if password contains at least one uppercase letter.
    if (!/[A-Z]/.test(password)) {
        errors.push("Password must contain at least one uppercase letter.");
    }
    // check if password contains at least one number.
    if (!/\d/.test(password)) {
        errors.push("Password must contain at least one number.");
    }
    // check if password contains at least one special character.
    if (!/[@$#!%^*?&]/.test(password)) {
        errors.push("Password must contain at least one special character.");
    }
    // return true if no errors, otherwise return array of error messages.
    return errors.length === 0 ? true : errors;
}

// sorting items by name function
function sort_by_item_name(){
    var item_order_type=$("#item-sort-icon").attr("data-item-sort-status");
    if(item_order_type=="DESC"){
        $("#item-sort-icon").attr("data-item-sort-status","ASC");
         $("#item-sort-icon").html(z_a_sort_icon);
    }
    else{
        $("#item-sort-icon").attr("data-item-sort-status","DESC");
         $("#item-sort-icon").html(a_z_sort_icon);
    }
    get_items($("#item-sort-icon").attr("data-item-sort-status"),"Items.Name");
}

// sorting items by price function
function sort_by_price(){
    var price_order_type=$("#price-sort-icon").attr("data-price-sort-status");
    if(price_order_type=="DESC"){
        $("#price-sort-icon").attr("data-price-sort-status","ASC");
         $("#price-sort-icon").html(sort_down);
    }
    else{
        $("#price-sort-icon").attr("data-price-sort-status","DESC");
         $("#price-sort-icon").html(sort_up);
    }
    get_items($("#price-sort-icon").attr("data-price-sort-status"),"Price");
}

// get items function
function get_items(sort_type,sort_by) {
    var item_name = $("#item_name").val();
    var item_type = $("#item_type").val();
    sort_type_g=sort_type;
    sort_by_g=sort_by;

    $.ajax({method: "POST",
        url: "../server/controller.php",
        dataType: "json",
        data: {request: "get_items", item_name: item_name, item_type: item_type, sort_by:sort_by,sort_type:sort_type},
        success: function (data) {
            generate_items_cards(data);
        }
    });
}

// adding items function
function add_item() {
    var item = $("#item").val();
    var image = $("#image").val();
    var price = $("#price").val();
    var type = $("#type").val();
    var description = $("#description").val();

    $.ajax({method: "POST",
        url: "../server/controller.php",
        dataType: "json",
        data: {request: "add_item", item_name: item, image: image, price: price, type: type, description: description},
        success: function (data) {
            if (data["success"]) {
                $("#add-item-success").show();
                get_items(sort_type_g,sort_by_g);
            }
        }
    });
}

// deleting items function
function delete_item(delitem) {
    var item_id = $(delitem).attr("data-item-id");
    // when admin want to delete an item, a confirmation message will appear.
    let confirmationMessage = prompt("To confirm deletion, please enter 'DELETE':");

    // check if admin entered 'DELETE' to confirm deletion.
    if (confirmationMessage !== null && confirmationMessage.toUpperCase() === 'DELETE') {
        $.ajax({
            method: "POST",
            url: "../server/controller.php",
            dataType: "json",
            data: {request: "delete_item", item_id: item_id},
            success: function (data) {
                if (data["success"]) {
                    get_items(sort_type_g, sort_by_g);
                }
            }
        });
    } else {
        alert("Deletion cancelled. You did not enter 'DELETE'.");
    }
}

// check if the current page is the admin page, as the user cant delete items.
var isAdminPage = location.pathname.includes("adminitems.html");

// function to generate items in cards.
function generate_items_cards(data) {
    // initialize an empty string to store the cards.
    var html = "";

    // loop through each item in the data array
    for (var index in data) {
        var item_id = data[index]["item_id"];
        var item_name = data[index]["item_name"];
        var item_artist = data[index]["item_artist"];
        var item_type = data[index]["item_type"];
        var price = data[index]["price"];
        var image = data[index]["image"];
        var description = data[index]["description"];

        // add the cards to the empty string.
        html += `
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">${item_name}</h5>
                    <div class="img-desc">
                        <img src='${image}' alt='${item_name}'>
                        <div class="desc-content">
                            <div class="desc">${description}</div>
                        </div>
                    </div>
                    <p class="card-text">Type: ${item_type}</p>
                    <p class="card-text">By: ${item_artist}</p>
                    <p class="card-text">${price} AED</p>
                    <!-- include delete button if its an admin page -->
                    ${isAdminPage ? `<button class="btn btn-danger delete-btn" onclick='delete_item(this);' data-item-id="${item_id}">Delete</button>` : ''}
                </div>
            </div>
        `;
    }
    // update the items container with generated cards.
    $("#items-container").html(html);
}

// function to display new items in carousel.
function display_new_items() {
    $.ajax({method: "POST",
        url: "../server/controller.php",
        dataType: "json",
        data: { request: "get_new_items" },
        success: function(data) {
            
            // initialize an empty string to store the new items.
            var newItemsHtml = '';
            // loop through each item in the data array.
            data.forEach(function(newItems) {
                // add the item to the empty string.
                newItemsHtml += `
                    <div style="height: 420px;" class="card">
                    <div class="card-body">
                        <h5 class="card-title">${newItems.Name}</h5>
                        <img class="img-desc" src='${newItems.Image}'>
                        <p class="card-text"> ${newItems.Type} </p>
                        <p class="card-text"> ${newItems.Price} AED </p>
                    </div>
                    </div>
                `;                
            });
            // add items to the new items container.
            $("#new-items").append(newItemsHtml);

            // initialize carousel after items are appended.
            $('#new-items').owlCarousel({
                loop:true,
                autoplay:true, 
                autoplayTimeout:3000, // will move every 3 seconds.
                // settings for different screen sizes.
                responsive:{
                    0:{
                        // Display 1 item on screens smaller than 600px
                        items:1
                    },
                    600:{
                        // Display 2 item on screens between 600px and 999px
                        items:2
                    },
                    1000:{
                        // Display 4 item on screens smaller 1000px and larger
                        items:4
                    }
                }
            });
        }
    });
}

// function to submit feedback
function submitFeedback() {
    var name = $("#feedback-name").val();
    var comment = $("#feedback-comment").val();
    var rate = $("#feedback-rate").val();

    $.ajax({method: "POST",
        url: "../server/controller.php",
        dataType: "json",
        data: {request: "save_feedback",name: name, comment: comment, rate: rate},
        success: function (data) {
            if (data["success"]) {
                // show a success message if feedback was submitted successfully
                alert("Thank you for your feedback!");
                // reset the feedback form after successful submission
                $("#feedback-form")[0].reset();
                
            } else {
                // show an error message if failed to submit feedback
                alert("Failed to submit feedback. Please try again.");
            }
        }
    });
}

// function to display user feedback in carousel.
function display_user_feedback() {
    $.ajax({method: "POST",
        url: "../server/controller.php",
        dataType: "json",
        data: { request: "get_user_feedback" },
        success: function(data) {

            // initialize an empty string to store the feedbacks.
            var feedbackHtml = '';
             // loop through each feedback in the data array.
            data.forEach(function(feedback) {
                // add the feedback to the empty string.
                feedbackHtml += `
                <div class="user-feedback">
                    <h3>${feedback.Name}</h3>
                    <p>${feedback.Comment}</p>
                    <p>Rating: ${feedback.Rate}</p>
                    </div>`;
                });
                // add feedbacks to the feedbacks container.
                $("#user-feedbacks").append(feedbackHtml);

                // initialize carousel after feedbacks are appended.
                $('#user-feedbacks').owlCarousel({
                    loop:true,
                    autoplay:true,
                    autoplayTimeout:4000, // will move every 4 seconds.
                    // settings for different screen sizes.
                    responsive:{
                        0:{
                            // Display 1 item on screens smaller than 600px
                            items:1
                        },
                        600:{
                            // Display 3 item on screens between 600px and 999px
                            items:3
                        },
                        1000:{
                            // Display 5 item on screens smaller 1000px and larger
                            items:5
                        }
                    }
                });
        }
    });
}